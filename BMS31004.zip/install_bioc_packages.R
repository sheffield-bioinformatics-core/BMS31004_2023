if(!require(BiocManager)) install.packages("BiocManager")
BiocManager::install(c("limma", 
         "org.Hs.eg.db", 
         "RColorBrewer", 
         "DESeq2",
         "pheatmap",
         "rmarkdown",
         "tximport",
         "DOSE",
         "biomaRt",
         "dplyr",
         "ggplot2"),suppressUpdates=TRUE)
packageurl <- "https://cran.r-project.org/src/contrib/Archive/rvcheck/rvcheck_0.1.8.tar.gz"
install.packages(packageurl, repos=NULL, type="source")
BiocManager::install("clusterProfiler")